import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { createAnecdote } from "../requests";
import { useNotificationDispatch } from "../NotificationContext";
import { useState } from "react";

const getId = () => Math.floor(Math.random() * 100000);

const AnecdoteForm = () => {
  const queryClient = useQueryClient();
  const dispatch = useNotificationDispatch();
  const [inputText, setInputText] = useState("");

  const newAnecdoteMutation = useMutation(createAnecdote, {
    onSuccess: (data) => {
      queryClient.invalidateQueries("anecdotes");

      dispatch({
        type: "SET_NOTIFICATION",
        payload: `Anecdote '${data.content}' created`,
      });
    },
    onError: (err) => {
      dispatch({
        type: "SET_NOTIFICATION",
        payload: err.response.data.error,
      });
    },
  });

  const addAnecdote = async (event) => {
    event.preventDefault();
    const content = event.target.anecdote.value;
    event.target.anecdote.value = "";
    newAnecdoteMutation.mutate({ content, id: getId(), votes: 0 });
    setTimeout(() => {
      dispatch({ type: "CLEAR_NOTIFICATION" });
    }, 5000);
  };

  function handleInputTextChange(event) {
    setInputText(event.target.value);
  }

  return (
    <div>
      <h3>create new</h3>
      <form onSubmit={addAnecdote}>
        <input name="anecdote" onChange={handleInputTextChange} />
        <button type="submit" disabled={inputText.length < 5}>
          create
        </button>
      </form>
    </div>
  );
};

export default AnecdoteForm;
