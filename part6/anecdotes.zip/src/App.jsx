import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { initializeQuotes } from "./reducers/quoteReducer";
import Header from "./components/Header";
import Notification from "./components/Notification";
import Filter from "./components/Filter";
import Quotes from "./components/Quotes";
import SectionHeader from "./components/SectionHeader";
import NewQuote from "./components/NewQuote";
import Footer from "./components/Footer";

export default function App() {
  const [searchText, setSearchText] = useState("");

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(initializeQuotes());
  }, []);

  function handleSearchChange(event) {
    setSearchText(event.target.value);
  }

  return (
    <div>
      <Header />
      <Notification />
      <Filter onSearchChange={handleSearchChange} searchText={searchText} />
      <Quotes searchText={searchText} />
      <SectionHeader />
      <NewQuote />
      <Footer />
    </div>
  );
}
