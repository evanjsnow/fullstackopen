const notificationReducer = (state = "HIDE", action) => {
  switch (action.type) {
    case "SET_NOTIFICATION":
      return action.payload;
    default:
      return state;
  }
};

export const changeNotification = (message, action) => {
  return {
    type: "SET_NOTIFICATION",
    payload: message,
  };
};

export const setNotification = () => {
  return (dispatch) => {
    dispatch(changeNotification("SHOW"));

    setTimeout(() => {
      dispatch(changeNotification("HIDE"));
    }, 2000);
  };
};

export default notificationReducer;
