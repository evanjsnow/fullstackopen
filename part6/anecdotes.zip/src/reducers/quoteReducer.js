import { createSlice } from "@reduxjs/toolkit";
import quoteService from "../services/quotes";

const initialState = [];

const quoteSlice = createSlice({
  name: "quotes",
  initialState,
  reducers: {
    appendQuote(state, action) {
      state.push(action.payload);
    },
    setQuotes(state, action) {
      return action.payload;
    },
  },
});

export const { appendQuote, setQuotes } = quoteSlice.actions;

export const initializeQuotes = () => {
  return async (dispatch) => {
    const quotes = await quoteService.getAll();
    dispatch(setQuotes(quotes));
  };
};

export const createQuote = (content) => {
  return async (dispatch) => {
    const newQuote = await quoteService.createNew(content);
    dispatch(appendQuote(newQuote));
  };
};

export const handleVoteClick = (state) => {
  return async (dispatch) => {
    const quote = state;
    const updatedQuote = { ...quote, votes: quote.votes + 1 };
    const votePlusOne = await quoteService.update(state.id, updatedQuote);
    const quotes = await quoteService.getAll();
    const updatedQuotes = await quotes.map((quote) =>
      quote.id === state.id ? votePlusOne : quote
    );
    dispatch(setQuotes(updatedQuotes));
  };
};

export default quoteSlice.reducer;
