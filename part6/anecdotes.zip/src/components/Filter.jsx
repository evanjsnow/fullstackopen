import { filterChange } from "../reducers/filterReducer";
import { useDispatch } from "react-redux";
import { useEffect } from "react";

export default function Filter({ onSearchChange, searchText }) {
  const dispatch = useDispatch();

  useEffect(() => {
    if (searchText.length === 0) {
      dispatch(filterChange("ALL"));
    } else if (searchText.length > 0) {
      dispatch(filterChange("STARTS_WITH"));
    }
  }, [searchText]);

  const searchFilter = (
    <div className="searchBlock">
      <span className="searchLabel">Quote Starts With: </span>
      <input
        type="text"
        className="textField searchField"
        name="filter"
        onChange={onSearchChange}
      />
    </div>
  );

  return searchFilter;
}
