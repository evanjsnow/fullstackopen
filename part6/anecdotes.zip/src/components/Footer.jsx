export default function Footer() {
  return (
    <div className="footerStyle">
      Quotes App by Evan Snow{" "}
      <i className="fa-regular fa-copyright faSmallLight"></i> 2023 &mdash;
      Inspired by Full Stack Open, University of Helsinki
    </div>
  );
}
