import { useSelector, useDispatch } from "react-redux";
import { handleVoteClick } from "../reducers/quoteReducer";

const Quote = ({ quote, onVoteClick }) => {
  return (
    <li>
      {quote.content}{" "}
      <button onClick={onVoteClick}>Vote ({quote.votes})</button>
    </li>
  );
};

const Quotes = ({ searchText }) => {
  const dispatch = useDispatch();

  const quotes = useSelector((state) => {
    if (state.filter === "ALL") {
      return state.quotes;
    }
    return (
      state.filter === "STARTS_WITH" &&
      state.quotes.filter((quote) =>
        quote.content.toLowerCase().startsWith(searchText.toLowerCase())
      )
    );
  });

  const quotesByVotes = [...quotes].sort((a, b) => b.votes - a.votes);

  return (
    <ul>
      {quotesByVotes.length === 0 ? (
        <span className="noMatches">No matches found</span>
      ) : (
        quotesByVotes.map((quote) => (
          <Quote
            key={quote.id}
            quote={quote}
            onVoteClick={() => dispatch(handleVoteClick(quote))}
          />
        ))
      )}
    </ul>
  );
};

export default Quotes;
