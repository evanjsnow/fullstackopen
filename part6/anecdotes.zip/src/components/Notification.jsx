import { useSelector } from "react-redux";

export default function Notification() {
  const message = useSelector((state) => {
    if (state.notification === "HIDE") {
      return null;
    } else if (state.notification === "SHOW") {
      return "New quote added";
    }
  });

  const messageClass = useSelector((state) => {
    if (state.notification === "HIDE") {
      return null;
    } else if (state.notification === "SHOW") {
      return "bar good";
    }
  });

  return <div className={messageClass}>{message}</div>;
}
