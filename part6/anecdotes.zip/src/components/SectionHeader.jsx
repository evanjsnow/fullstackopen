export default function SectionHeader() {
  return (
    <>
      <br />
      <hr />
      <br />
      <h2>Create a New Quote</h2>
    </>
  );
}
