import { useDispatch } from "react-redux";
import { createQuote } from "../reducers/quoteReducer";
import { setNotification } from "../reducers/notificationReducer";
import { useState } from "react";

export default function NewQuote() {
  const dispatch = useDispatch();
  const [newQuote, setNewQuote] = useState("");

  function handleNewQuoteChange(e) {
    setNewQuote(e.target.value);
  }

  const addQuote = async (event) => {
    event.preventDefault();
    const content = event.target.quote.value;
    event.target.quote.value = "";
    setNewQuote("");
    dispatch(createQuote(content));
    dispatch(setNotification());
  };

  return (
    <form onSubmit={addQuote}>
      <div>
        <input
          className="textField newQuoteField"
          name="quote"
          onChange={handleNewQuoteChange}
        />
        <br />
        <br />
      </div>
      <button
        className="newQuoteButton"
        type="submit"
        value={newQuote}
        disabled={newQuote.length === 0}
      >
        Create New Quote
      </button>
    </form>
  );
}
