const listHelper = require("../utils/list_helper");

describe("author with most likes", () => {
  const listWithAuthorWithManyLikes = [
    {
      _id: "5a422aa71b54a676234d17f7",
      title: "Go To Statement Considered Harmful",
      author: "Alex Snow",
      url: "http://www.u.arizona.edu/~rubinson/copyright_violations/Go_To_Considered_Harmful.html",
      likes: 50,
      __v: 0,
    },
    {
      _id: "5a422aa71b54a676234d17f8",
      title: "Testes",
      author: "PeePee PooPoo",
      url: "http://www.u.arizona.edu",
      likes: 500,
      __v: 1,
    },
    {
      _id: "5a422aa71b54a676234d17f9",
      title: "I See OJ",
      author: "Lester Higgins",
      url: "http://www.u.arizona.edu",
      likes: 3,
      __v: 1,
    },
    {
      _id: "5a422aa71b54a676234d17f5",
      title: "All About My Butt",
      author: "PeePee PooPoo",
      url: "http://www.u.arizona.edu",
      likes: 1,
      __v: 0,
    },
    {
      _id: "5a422aa71b54a676234d17f6",
      title: "Show The Finger",
      author: "Alex Snow",
      url: "http://www.u.arizona.edu",
      likes: 100,
      __v: 0,
    },
  ];

  test("get the author with the most likes", () => {
    const result = listHelper.mostLikes(listWithAuthorWithManyLikes);
    expect(result).toEqual({
      author: "PeePee PooPoo",
      likes: 501,
    });
  });
});
