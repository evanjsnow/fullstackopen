const Blog = require("../models/blog");
const User = require("../models/user");

const initialBlogs = [
  {
    _id: "5a422aa71b54a676234d17f9",
    title: "I See OJ",
    author: "Lester Higgins",
    url: "http://www.u.arizona.edu",
    likes: 3,
    __v: 1,
  },
  {
    _id: "5a422aa71b54a676234d17f5",
    title: "All About My Butt",
    author: "PeePee PooPoo",
    url: "http://www.u.arizona.edu",
    likes: 1,
    __v: 0,
  },
];

const nonExistingId = async () => {
  const blog = new Blog();
  await blog.save();
  await blog.deleteOne();

  return blog._id.toString();
};

const blogsInDb = async () => {
  const blogs = await Blog.find({});
  return blogs.map((blog) => blog.toJSON());
};

const usersInDb = async () => {
  const users = await User.find({});
  return users.map((u) => u.toJSON());
};

module.exports = {
  initialBlogs,
  nonExistingId,
  blogsInDb,
  usersInDb,
};
