const _ = require("lodash");

const mostLikes = (blogs) => {
  const blogInfo = [];
  blogs.forEach((blog) => {
    blogInfo.push({
      author: blog.author,
      likes: blog.likes,
    });
  });
  const authList = _.groupBy(blogInfo, "author");
  const authListArr = Object.entries(authList);
  const authListLikes = [];
  authListArr.forEach((entry) => {
    authListLikes.push({
      author: entry[0],
      likes: _.sumBy(entry[1], "likes"),
    });
  });

  const orderedList = _.orderBy(authListLikes, ["likes"], ["desc"]);
  return orderedList[0];
};

const mostBlogs = (blogs) => {
  const countList = _.countBy(blogs, "author");
  const countArr = Object.entries(countList);

  function sortCountArr() {
    countArr.sort((a, b) => {
      return b[1] - a[1];
    });
  }

  sortCountArr();
  const topCount = {
    author: countArr[0][0],
    blogs: countArr[0][1],
  };
  return topCount;
};

const sumLikes = (blogs) => {
  const likesArr = blogs.map((blog) => blog.likes);
  const likesSum = likesArr.reduce((total, current) => total + current, 0);
  return likesSum;
};

const favoriteBlog = (blogs) => {
  function sortBlogs() {
    blogs.sort((a, b) => {
      return b.likes - a.likes;
    });
  }
  sortBlogs();
  const bestBlog = {
    title: blogs[0].title,
    author: blogs[0].author,
    likes: blogs[0].likes,
  };

  return bestBlog;
};

module.exports = {
  sumLikes,
  favoriteBlog,
  mostBlogs,
  mostLikes,
};
