import { useState, useEffect } from "react";
import { useQuery, useMutation, useApolloClient } from "@apollo/client";
import { LOGIN, ALL_BOOKS, ALL_AUTHORS } from "./queries";
import { Routes, Route, useNavigate } from "react-router-dom";
import GlobalHeader from "./components/GlobalHeader";
import Notify from "./components/Notify";
import BookPage from "./components/BookPage";
import AuthorList from "./components/AuthorList";
import Footer from "./components/Footer";

export default function App() {
  const [token, setToken] = useState(
    localStorage.getItem("library-user-token")
  );
  const [usersName, setUsersName] = useState(localStorage.getItem("usersName"));
  const authorList = useQuery(ALL_AUTHORS);
  const bookList = useQuery(ALL_BOOKS);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const client = useApolloClient();
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  function handleSuccessNotification(message) {
    setSuccessMessage(message);
    setTimeout(() => {
      setSuccessMessage(null);
    }, 2000);
  }

  function handleErrorNotification(message) {
    setErrorMessage(message);
    setTimeout(() => {
      setErrorMessage(null);
    }, 2000);
  }

  const [login, loginResult] = useMutation(LOGIN, {
    onError: (error) => {
      handleErrorNotification(error.graphQLErrors[0].message);
    },
  });

  useEffect(() => {
    if (loginResult.data) {
      const token = loginResult.data.login.value;
      setToken(token);
      localStorage.setItem("library-user-token", token);
      localStorage.setItem("usersName", username);
    }
  }, [loginResult.data]);

  async function handleLogin(event) {
    event.preventDefault();

    login({ variables: { username, password } });
  }

  const navigate = useNavigate();

  function handleLogout() {
    setToken(null);
    localStorage.clear();
    client.resetStore();
    navigate("/");
  }

  const signInForm = (
    <div className="signIn">
      <h1>Sign In</h1>
      <form onSubmit={handleLogin}>
        <div>
          Username:
          <br />
          <input
            type="text"
            className="textFieldClass"
            value={username}
            name="username"
            onChange={({ target }) => setUsername(target.value)}
          />
        </div>
        <div>
          Password:
          <br />
          <input
            type="password"
            className="textFieldClass"
            value={password}
            name="password"
            onChange={({ target }) => setPassword(target.value)}
          />
        </div>
        <button type="submit">Sign In</button>
      </form>
    </div>
  );

  if (bookList.loading || authorList.loading) {
    return <div>loading...</div>;
  }

  return (
    <>
      <Notify errorMessage={errorMessage} successMessage={successMessage} />
      <GlobalHeader
        token={token}
        onLogout={handleLogout}
        usersName={usersName}
      />
      {!token && signInForm}
      {token && (
        <Routes>
          <Route
            path="/"
            element={
              <BookPage
                bookList={bookList.data.allBooks}
                onErrorNotification={handleErrorNotification}
                onSuccessNotification={handleSuccessNotification}
              />
            }
          />
          <Route
            path="/authors"
            element={<AuthorList authorList={authorList} bookList={bookList} />}
          />
        </Routes>
      )}
      <Footer />
    </>
  );
}
