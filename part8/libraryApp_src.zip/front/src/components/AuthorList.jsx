import { useState } from "react";
import { useMutation } from "@apollo/client";
import { EDIT_AUTHOR, ALL_AUTHORS } from "../queries";
import { Link } from "react-router-dom";

export default function AuthorList({ authorList, bookList }) {
  const [inlineClass, setInlineClass] = useState("hideThing");
  const [selectedAuthor, setSelectedAuthor] = useState(null);
  const [born, setBorn] = useState("");

  function handleEditAuthorClick(author) {
    setSelectedAuthor(author.id);
    setInlineClass("inlineDBG");
  }

  function handleInlineClose() {
    setInlineClass("hideThing");
  }

  function handleformClear(event) {
    event.preventDefault();
    handleInlineClose();
    setSelectedAuthor(null);
    setBorn("");
  }

  const [updateBorn] = useMutation(EDIT_AUTHOR, {
    refetchQueries: [{ query: ALL_AUTHORS }, "getAllAuthors"],
  });

  async function handleUpdateBornSubmit(event) {
    event.preventDefault();
    const targetAuthor =
      selectedAuthor &&
      (await authorList.data.allAuthors.find(
        (author) => author.id === selectedAuthor
      ));
    const name = (await selectedAuthor) && targetAuthor.name;

    updateBorn({ variables: { name, born } });

    setSelectedAuthor(null);
    setBorn("");

    setTimeout(() => {
      handleInlineClose();
    }, 200);
  }

  const getAuthorBookCount = (author) => {
    const authorBookList = bookList.data.allBooks.filter(
      (book) => book.author.name === author.name
    );
    return authorBookList.length;
  };

  const authorTable = (
    <>
      <div className="listHeader">
        <h1>All Authors</h1>
      </div>
      <div className="listContainer authorListContainer">
        <table className="tableMargin">
          <tbody>
            <tr>
              <td className="columnHeader">Author</td>
              <td className="columnHeader numberColumn">Born</td>
              <td className="columnHeader numberColumn">Books</td>
            </tr>
            {authorList.data.allAuthors.map((author) => (
              <tr key={author.id}>
                <td className="bookTitle">{author.name}</td>
                <td className="bookTitle lighten numberColumn">
                  {author.born ? (
                    author.born
                  ) : (
                    <>
                      <Link onClick={() => handleEditAuthorClick(author)}>
                        <i className="fa-solid fa-calendar-plus"></i>
                      </Link>
                      {selectedAuthor === author.id && (
                        <form
                          className={inlineClass}
                          onSubmit={handleUpdateBornSubmit}
                        >
                          <input
                            className="authorYearField"
                            type="number"
                            value={born}
                            onChange={({ target }) =>
                              setBorn(Number.parseInt(target.value, 10))
                            }
                          />
                          <Link
                            className="inlineCloseX"
                            onClick={handleInlineClose}
                          >
                            <i className="fa-solid fa-x"></i>
                          </Link>
                        </form>
                      )}
                    </>
                  )}
                </td>
                <td className="bookTitle lighten numberColumn">
                  {getAuthorBookCount(author)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );

  return authorTable;
}
