import { useState } from "react";
import AuthorList from "./AuthorList";
import InlineD from "./InlineD";

export default function Authors({ authorList, bookList }) {
  const [inlineClass, setInlineClass] = useState("hideThing");
  const [selectedAuthor, setSelectedAuthor] = useState(null);

  function handleEditAuthorClick(author) {
    setSelectedAuthor(author.id);
    setInlineClass("inlineDBG");
  }

  function handleInlineClose() {
    setSelectedAuthor(null);
    setInlineClass("hideThing");
  }

  return (
    <>
      <AuthorList
        authorList={authorList}
        bookList={bookList}
        onEditAuthorClick={handleEditAuthorClick}
        selectedAuthor={selectedAuthor}
        inlineClass={inlineClass}
        onInlineClose={handleInlineClose}
      />
    </>
  );
}
