import { useState } from "react";
import { useMutation } from "@apollo/client";
import { EDIT_AUTHOR, ALL_AUTHORS } from "../queries";
import { Link } from "react-router-dom";

export default function InlineD({ inlineClass, onInlineClose }) {
  const [born, setBorn] = useState("");

  const [updateBorn] = useMutation(EDIT_AUTHOR, {
    refetchQueries: [{ query: ALL_AUTHORS }, "getAllAuthors"],
  });

  function handleUpdateBornSubmit(event) {
    event.preventDefault();
    updateBorn({ variables: { born } });

    setTimeout(() => {
      onInlineClose();
    }, 200);
  }

  return (
    <form className={inlineClass} onSubmit={handleUpdateBornSubmit}>
      <input
        className="authorYearField"
        type="number"
        name="bornField"
        value={born}
        onChange={({ target }) => setBorn(target.value)}
      />
      <Link className="inlineCloseX" onClick={onInlineClose}>
        <i className="fa-solid fa-x"></i>
      </Link>
    </form>
  );
}
