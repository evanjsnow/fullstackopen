import { useIcon } from "../hooks/useIcon";

export default function FilterPanel({
  bookList,
  selectedGenreID,
  onGenreFilterClick,
}) {
  function getUniqueGenres() {
    const allGenres = bookList.map((book) => book.genres.flat());
    const flatGenres = allGenres.flat();
    const uniqGenres = [];
    for (let i = 0; i < flatGenres.length; i++) {
      flatGenres.forEach((genre) => {
        if (uniqGenres.includes(flatGenres[i]) === false) {
          uniqGenres.push(flatGenres[i]);
        }
      });
    }
    const uniqGenreList = uniqGenres.sort();
    uniqGenreList.unshift("All Genres");
    return uniqGenreList.map((genre) => (
      <button
        id={genre.replace(" ", "")}
        className="filterList"
        key={genre}
        onClick={() => onGenreFilterClick(genre)}
      >
        {useIcon(genre)}
      </button>
    ));
  }

  return (
    <>
      <h2 className="filterHeader">Genre</h2>
      <div className="filterPanel">{getUniqueGenres()}</div>
    </>
  );
}
