import { Link } from "react-router-dom";
import NewBookForm from "./NewBookForm";

export default function ModalD({
  modalClass,
  onModalClose,
  onSuccessNotification,
}) {
  return (
    <>
      <div className={modalClass}>
        <Link className="closeX" onClick={onModalClose}>
          <i className="fa-solid fa-x"></i>
        </Link>
        <div className="modalTitle">
          <h1>Add a New Book</h1>
        </div>
        <NewBookForm
          onModalClose={onModalClose}
          onSuccessNotification={onSuccessNotification}
        />
      </div>
    </>
  );
}
