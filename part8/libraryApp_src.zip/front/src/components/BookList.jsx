export default function BookList({ bookList }) {
  const bookTable = (
    <>
      <div className="listContainer bookListContainer">
        <table className="tableMargin">
          <tbody>
            <tr>
              <td className="columnHeader">Books</td>
              <td className="columnHeader">Author</td>
              <td className="columnHeader numberColumn">Published</td>
              <td className="columnHeader">Genres</td>
            </tr>
            {bookList.map((book) => (
              <tr key={book.id}>
                <td className="bookTitle">{book.title}</td>
                <td className="bookTitle lighten">{book.author.name}</td>
                <td className="bookTitle lighten numberColumn">
                  {book.published}
                </td>
                <td className="lighten small">{book.genres.join(", ")}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );

  return bookTable;
}
