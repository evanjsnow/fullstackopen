export default function BooksHeader({ modalClass, onAddBookClick }) {
  return (
    <div className="listHeader">
      <span>
        <h1>All Books</h1>
      </span>
      <button onClick={onAddBookClick} className="buttonSmall addBookButton">
        <i className="fa-regular fa-circle-plus addBookIcon"></i>Add a new book
      </button>
    </div>
  );
}
