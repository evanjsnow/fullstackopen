import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

export default function Nav() {
  useEffect(() => {
    document.querySelector("#navBooks").classList.add("navCurrent");
  }, []);

  function setAuthorsNavCurrent() {
    document.querySelector("#navBooks").classList.remove("navCurrent");
    document.querySelector("#navAuthors").classList.add("navCurrent");
  }

  function setBooksNavCurrent() {
    document.querySelector("#navAuthors").classList.remove("navCurrent");
    document.querySelector("#navBooks").classList.add("navCurrent");
  }

  const navBar = (
    <>
      <div className="nav">
        <Link
          to="/"
          className="navLink"
          id="navBooks"
          onClick={setBooksNavCurrent}
        >
          <i className="fa-duotone fa-book navIcon"></i>Books
        </Link>
        <Link
          to="/authors"
          className="navLink"
          id="navAuthors"
          onClick={setAuthorsNavCurrent}
        >
          <i className="fa-solid fa-user-pen navIcon"></i>Authors
        </Link>
      </div>
    </>
  );

  return navBar;
}
