import { useState } from "react";
import { useMutation } from "@apollo/client";
import { CREATE_BOOK, ALL_BOOKS, ALL_AUTHORS } from "../queries";

export default function NewBookForm({
  onModalClose,
  onErrorNotification,
  onSuccessNotification,
}) {
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [published, setPublished] = useState("");
  const [genreString, setGenreString] = useState("");
  const [name, setName] = useState("");

  const [createBook] = useMutation(CREATE_BOOK, {
    refetchQueries: [
      { query: ALL_BOOKS },
      "getAllBooks",
      { query: ALL_AUTHORS },
      "getAllAuthors",
    ],
    onError: (error) => {
      const messages = error.graphQLErrors.map((e) => e.message).join("\n");
      onErrorNotification(messages);
    },
  });

  function arrayifyGenres(event) {
    setGenreString(event.target.value);
  }

  async function handleAddBookSubmit(event) {
    event.preventDefault();
    const genreArr = await genreString.split(",");
    const genres = await genreArr.map((genre) => genre.trimStart());
    createBook({ variables: { title, author, published, genres } });
    setTitle("");
    setAuthor("");
    setPublished("");
    setGenreString("");
    setName("");
    setTimeout(() => {
      onModalClose();
    }, 300);
    onSuccessNotification("New book created");
  }

  function handleFormClear(event) {
    event.preventDefault();
    onModalClose();
    setTitle("");
    setAuthor("");
    setPublished("");
    setGenreString("");
    setName("");
  }

  return (
    <>
      <div className="newBookFormContainer">
        <form onSubmit={handleAddBookSubmit}>
          <label className="fieldLabel">Title:</label>
          <input
            className="textFieldClass"
            value={title}
            onChange={({ target }) => setTitle(target.value)}
          />
          <label className="fieldLabel">Author:</label>
          <input
            className="textFieldClass"
            value={author}
            onChange={({ target }) => {
              setAuthor(target.value), setName(target.value);
            }}
          />
          <label className="fieldLabel">Published:</label>
          <input
            className="textFieldClass"
            value={published}
            onChange={({ target }) =>
              setPublished(Number.parseInt(target.value, 10))
            }
          />
          <label className="fieldLabel">Genres:</label>
          <input
            value={genreString}
            className="textFieldClass"
            onChange={arrayifyGenres}
          />
          <span className="helpText">
            <i className="fa-solid fa-circle-info"></i> Separate genres with a
            comma
          </span>
          <div className="addBookButtonBlock">
            <button className="cancelButton" onClick={handleFormClear}>
              Cancel
            </button>
            <button className="addButton">Add Book</button>
          </div>
        </form>
      </div>
    </>
  );
}
