import Nav from "./Nav";
import WelcomeUser from "./WelcomeUser";

export default function GlobalHeader({ token, onLogout, usersName }) {
  return (
    <>
      <div className="pageTitle">
        <i className="fa-duotone fa-books titleLogo"></i>
        <span className="titleText">Books Galore</span>
      </div>
      {token && (
        <>
          <Nav />
          <WelcomeUser onLogout={onLogout} usersName={usersName} />
        </>
      )}
    </>
  );
}
