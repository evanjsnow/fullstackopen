import { useQuery } from "@apollo/client";
import { ALL_BOOKS, BOOKS_BY_GENRE } from "../queries";
import BookList from "./BookList";
import ModalD from "./ModalD";

export default function Books({
  bookList,
  onSuccessNotification,
  selectedGenre,
  onModalClose,
  modalClass,
}) {
  const filterList = !selectedGenre
    ? useQuery(ALL_BOOKS)
    : useQuery(BOOKS_BY_GENRE, { variables: { selectedGenre } });

  if (filterList.loading) {
    return <div>loading...</div>;
  }

  return (
    <>
      <BookList bookList={filterList.data.allBooks} />
      <ModalD
        onModalClose={onModalClose}
        modalClass={modalClass}
        onSuccessNotification={onSuccessNotification}
      />
    </>
  );
}
