export default function Notify({ errorMessage, successMessage }) {
  if (!errorMessage && !successMessage) {
    return null;
  } else if (errorMessage) {
    return (
      <div className="bar bad">
        <i className="fa-solid fa-circle-exclamation notifyIcon"></i>
        {errorMessage}
      </div>
    );
  } else if (successMessage) {
    return (
      <div className="bar good">
        <i className="fa-solid fa-check notifyIcon"></i>
        {successMessage}
      </div>
    );
  }
}
