import { useState, useEffect } from "react";
import BooksHeader from "./BooksHeader";
import FilterPanel from "./FilterPanel";
import Books from "./Books";

export default function BookPage({
  bookList,
  onErrorNotification,
  onSuccessNotification,
}) {
  const [selectedGenre, setSelectedGenre] = useState(null);
  const [selectedGenreID, setSelectedGenreID] = useState("");
  const [modalClass, setModalClass] = useState("hideThing");

  useEffect(() => {
    document.querySelector("#AllGenres").classList.add("filterCurrent");
    setSelectedGenreID("AllGenres");
  }, []);

  function handleAddBookClick() {
    setModalClass("modalDBG");
  }

  function handleModalClose() {
    setModalClass("hideThing");
  }

  function handleGenreFilterClick(genre) {
    if (genre === "All Genres") {
      setSelectedGenre(null);
    } else {
      setSelectedGenre(genre);
    }
    const genreID = genre.replace(" ", "");
    document
      .querySelector(`#${selectedGenreID}`)
      .classList.remove("filterCurrent");
    document.querySelector(`#${genreID}`).classList.add("filterCurrent");
    setSelectedGenreID(genreID);
  }

  return (
    <>
      <BooksHeader
        modalClass={modalClass}
        onAddBookClick={handleAddBookClick}
      />
      <FilterPanel
        bookList={bookList}
        onGenreFilterClick={handleGenreFilterClick}
      />
      <Books
        bookList={bookList}
        onErrorNotification={onErrorNotification}
        onSuccessNotification={onSuccessNotification}
        selectedGenre={selectedGenre}
        selectedGenreID={selectedGenreID}
        onModalClose={handleModalClose}
        modalClass={modalClass}
      />
    </>
  );
}
