export default function WelcomeUser({ usersName, onLogout }) {
  return (
    <>
      <div className="welcomeUser">Signed in as {usersName}</div>
      <div className="signOutButton">
        <button className="buttonSmall signOutButton" onClick={onLogout}>
          Sign Out
        </button>
      </div>
    </>
  );
}
