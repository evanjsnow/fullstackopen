export function useIcon(genre) {
  if (genre === "Biography") {
    return (
      <>
        <i className="fa-solid fa-book-user genreIcon"></i>
        {genre}
      </>
    );
  } else if (genre === "Detective") {
    return (
      <>
        <i className="fa-solid fa-user-secret genreIcon"></i>
        {genre}
      </>
    );
  } else if (genre === "Fantasy") {
    return (
      <>
        <i className="fa-solid fa-hat-wizard genreIcon"></i>
        {genre}
      </>
    );
  } else if (genre === "Fiction") {
    return (
      <>
        <i className="fa-solid fa-typewriter genreIcon"></i>
        {genre}
      </>
    );
  } else if (genre === "Historical") {
    return (
      <>
        <i className="fa-solid fa-newspaper genreIcon"></i>
        {genre}
      </>
    );
  } else if (genre === "Magical Realism") {
    return (
      <>
        <i className="fa-solid fa-hand-holding-magic genreIcon"></i>
        {genre}
      </>
    );
  } else if (genre === "Poetry") {
    return (
      <>
        <i className="fa-solid fa-user-shakespeare genreIcon"></i>
        {genre}
      </>
    );
  } else if (genre === "Political") {
    return (
      <>
        <i className="fa-solid fa-landmark-dome genreIcon"></i>
        {genre}
      </>
    );
  } else if (genre === "Romance") {
    return (
      <>
        <i className="fa-solid fa-heart genreIcon"></i>
        {genre}
      </>
    );
  } else if (genre === "SciFi") {
    return (
      <>
        <i className="fa-solid fa-ufo genreIcon"></i>
        {genre}
      </>
    );
  } else {
    return (
      <>
        <i className="fa-solid fa-book genreIcon"></i>
        {genre}
      </>
    );
  }
}
