import { useState } from "react";

export default function useField(type) {
  const [value, setValue] = useState("");

  const className = "textFieldClass";

  function onChange(event) {
    setValue(event.target.value);
    console.log(value);
  }

  function onReset() {
    setValue("");
  }

  return {
    type,
    value,
    className,
    onChange,
    onReset,
  };
}
