import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { Entry } from "../types";
import patientService from "../services/patients";
import diagnosisService from "../services/diagnoses";
import { Button } from "@mui/material";
import { Link } from "react-router-dom";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import MaleIcon from "@mui/icons-material/Male";
import FemaleIcon from "@mui/icons-material/Female";
import TransgenderIcon from "@mui/icons-material/Transgender";

interface EntryProps {
  codes: any;
}

const PatientInfoPage = (): JSX.Element => {
  const location = useLocation();
  const { patientID } = location.state;
  const [name, setName] = useState("");
  const [gender, setGender] = useState("");
  const [job, setJob] = useState("");
  const [entries, setEntries] = useState([]);
  const [codeNames, setCodeNames] = useState([]);

  useEffect(() => {
    const fetchPatient = async () => {
      const thisPatient = await patientService.getPatient(patientID);
      setName(thisPatient.name);
      setGender(thisPatient.gender);
      setJob(thisPatient.occupation);
      setEntries(thisPatient.entries);
    };
    void fetchPatient();
  }, [patientID]);

  const CodeEntryList = ({ codes }: EntryProps) => {
    const getCodeName = async (code: any) => {
      const thisCode = await diagnosisService.getDiagnosis(code);
      return thisCode.data.name;
    };

    const codeList = codes.map((code: string) => (
      <tr key={code}>
        <td>{code}</td>
        <td>{getCodeName({ code })}</td>
      </tr>
    ));

    return (
      <div>
        <table>
          <tbody>
            <tr>
              <td>Code</td>
              <td>Diagnosis</td>
            </tr>
            {codeList}
          </tbody>
        </table>
      </div>
    );
  };

  const history = entries.map((entry: Entry) => (
    <div key={entry.id}>
      <p className="entryHeader">Notes from {entry.date}</p>
      <p className="entryDescription">{entry.description}</p>
      {entry.diagnosisCodes !== undefined && (
        <div>
          <CodeEntryList codes={entry.diagnosisCodes} />
        </div>
      )}
    </div>
  ));

  return (
    <>
      <Button component={Link} to="/" variant="contained" color="primary">
        <ArrowBackIosIcon style={{ fontSize: "1.2em" }} /> Back
      </Button>
      <h1>
        {name}
        {gender === "male" && (
          <MaleIcon fontSize="large" className="genderIcon" />
        )}
        {gender === "female" && (
          <FemaleIcon fontSize="large" className="genderIcon" />
        )}
        {gender === "other" && (
          <TransgenderIcon fontSize="large" className="genderIcon" />
        )}
      </h1>
      <h3 className="jobText">{job}</h3>
      <h2>History</h2>
      {history.length === 0 && "No visits recorded yet"}
      {history}
    </>
  );
};

export default PatientInfoPage;
