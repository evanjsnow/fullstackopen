import { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { loginUser, getLoggedUser } from "./reducers/loginReducer";
import { initializeBlogs } from "./reducers/blogReducer";
import { setLoginBadNotification } from "./reducers/notificationReducer";

import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link,
  Navigate,
  useParams,
  useNavigate,
  useMatch,
} from "react-router-dom";

import PageTitle from "./components/PageTitle";
import FormBlock from "./components/FormBlock";
import Notification from "./components/Notification";
import Nav from "./components/Nav";
import Blogs from "./components/Blogs";
import WelcomeUser from "./components/WelcomeUser";
import CreateBlog from "./components/CreateBlog";
import Users from "./components/Users";
import Footer from "./components/Footer";
import blogService from "./services/blogs";
import loginService from "./services/login";
import userService from "./services/users";

export default function App(props) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [users, setUsers] = useState([]);

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(initializeBlogs());
    dispatch(getLoggedUser());
    userService.getAll().then((response) => setUsers(response));
  }, []);

  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogappUser");
    if (loggedUserJSON) {
      const user = JSON.parse(loggedUserJSON);
      setUser(user);
      blogService.setToken(user.token);
    }
  }, []);

  const handleLogin = async (event) => {
    event.preventDefault();

    try {
      const username = event.target.username.value;
      const password = event.target.password.value;

      dispatch(loginUser(username, password));
      window.localStorage.setItem("loggedBlogappUser", JSON.stringify(user));
      blogService.setToken(user.token);

      setUsername("");
      setPassword("");
    } catch (exception) {
      setTimeout(() => {
        dispatch(setLoginBadNotification());
      }, 2000);
    }
  };

  function handleSignOutButtonClick() {
    window.localStorage.removeItem("loggedBlogappUser");
    window.location.reload(false);
  }

  const signInForm = (
    <div className="signIn">
      <form onSubmit={handleLogin}>
        <div>
          Username:
          <br />
          <input
            type="text"
            className="textFieldClass"
            value={username}
            name="username"
            onChange={({ target }) => setUsername(target.value)}
          />
        </div>
        <div>
          Password:
          <br />
          <input
            type="password"
            className="textFieldClass"
            value={password}
            name="password"
            onChange={({ target }) => setPassword(target.value)}
          />
        </div>
        <button type="submit">Sign In</button>
      </form>
    </div>
  );

  function HomeBlock() {
    return (
      <>
        <CreateBlog user={user.name} />
        <Blogs user={user.name} />
      </>
    );
  }

  return (
    <div>
      {user === null && <FormBlock form={signInForm} />}
      <Notification />
      <PageTitle />
      {user !== null && <Nav />}
      {user !== null && (
        <WelcomeUser
          user={user.name}
          onSignOutButtonClick={handleSignOutButtonClick}
        />
      )}
      {user !== null && (
        <Routes>
          <Route path="/" element={<HomeBlock user={user.name} />} />
          <Route path="/members" element={<Users users={users} />} />
        </Routes>
      )}
      <Footer />
    </div>
  );
}
