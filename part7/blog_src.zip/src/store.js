import { configureStore } from "@reduxjs/toolkit";

import loginReducer from "./reducers/loginReducer";
import blogReducer from "./reducers/blogReducer";
import notificationReducer from "./reducers/notificationReducer";

const store = configureStore({
  reducer: {
    blogs: blogReducer,
    notification: notificationReducer,
    login: loginReducer,
  },
});

store.subscribe(() => console.log(store.getState()));
export default store;
