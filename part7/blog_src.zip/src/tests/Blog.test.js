import React from "react";
import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import Blog from "./Blog";

test("renders initial content without details", () => {
  const blog = {
    title: "I'm About Meeting Girls",
    author: "Scores Man",
    url: "www.rmlimodriver69.com",
    likes: 69,
  };

  render(<Blog blog={blog} />);

  const element1 = screen.getByText("I'm About Meeting Girls");
  const element2 = screen.getByText("Scores Man");
  const element3 = screen.queryByText("www.rmlimodriver69.com");
  const element4 = screen.queryByText("likes");
  expect(element1).toBeDefined();
  expect(element2).toBeDefined();
  expect(element3).toBeNull();
  expect(element4).toBeNull();
});

test("renders details content", async () => {
  const blog = {
    title: "My Personal Life is a Noine",
    author: "Baba Booey",
    url: "www.mamamonkey.com",
    likes: 999999,
  };

  const showDetailsClick = jest.fn();

  render(<Blog blog={blog} handleShowDetailsClick={showDetailsClick} />);

  const user = userEvent.setup();
  const button = screen.queryByText("Show Details");
  await user.click(button);

  const element1 = await screen.getByText("My Personal Life is a Noine");
  const element2 = await screen.getByText("Baba Booey");
  const element3 = await screen.queryByText("www.mamamonkey.com");
  const element4 = await screen.queryByText("likes");
  expect(element1).toBeDefined();
  expect(element2).toBeDefined();
  expect(element3).toBeDefined();
  expect(element4).toBeDefined();
});

// NOTE: works when ignoring "Added by {blog.user.name"

test("click like twice", async () => {
  const blog = {
    title: "My Personal Life is a Noine",
    author: "Baba Booey",
    url: "www.mamamonkey.com",
    likes: 99,
  };

  const mockHandler = jest.fn();

  render(<Blog blog={blog} handleLikeClick={mockHandler} />);

  const user = userEvent.setup();
  const button = screen.queryByText("LIKE");
  await user.click(button);
  await user.click(button);

  expect(mockHandler.mock.calls).toHaveLength(2);
});
