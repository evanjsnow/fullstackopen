export default function PageTitle() {
  return (
    <div className="pageTitle">
      <i className="fa-duotone fa-blog titleLogo"></i>Evan's Blog-O-Rama!
    </div>
  );
}
