import { useState } from "react";
import { Link } from "react-router-dom";

export default function Blog({ blog, onDeleteClick, onLikeClick }) {
  const [selectedBlog, setSelectedBlog] = useState(null);
  const [blogCreator, setBlogCreator] = useState(blog.user.name);

  function handleShowDetailsClick(blog) {
    setSelectedBlog(blog.id);
  }

  function handleHideDetailsClick() {
    setSelectedBlog(null);
  }

  const hideDetailsButton = (
    <button className="button detailsButton" onClick={handleHideDetailsClick}>
      <span className="detailsText">Hide Details</span>
      <span className="detailsArrow">{`\u25b2`}</span>
    </button>
  );

  const showDetailsButtonText = (
    <>
      <span className="detailsText">Show Details</span>
      <span className="detailsArrow">{`\u25bc`}</span>
    </>
  );

  const url = blog.url;

  const linkyLink = `http://${url}`;

  return (
    <li>
      <span className="blogTitle">{blog.title}</span>
      <button className="deleteButton" onClick={() => onDeleteClick(blog)}>
        <i className="fa-solid fa-delete-left"></i>
      </button>
      <br />
      <span className="blogAuthor">{blog.author}</span>
      <div>
        {selectedBlog === blog.id ? (
          <div className="detailsList">
            {hideDetailsButton}
            <br />
            <a href={linkyLink} target="_blank">
              {url}
            </a>
            <br />
            Added by {blogCreator}
            <br />
            <span className="detailsLikes">{blog.likes}</span> likes{" "}
            <button className="likeIcon" onClick={() => onLikeClick(blog)}>
              <i className="fa-solid fa-thumbs-up"></i>
            </button>
          </div>
        ) : (
          <button
            className="button detailsButton"
            onClick={() => handleShowDetailsClick(blog)}
            children={showDetailsButtonText}
          ></button>
        )}
      </div>
    </li>
  );
}
