import { Link } from "react-router-dom";

export default function UserBlogs({
  blogListClass,
  targetUser,
  onPanelClose,
  userBlogs,
}) {
  function BlogDetails() {
    return (
      <div className={blogListClass}>
        <h2>Blogs Added by {targetUser.name}</h2>
        <Link className="closeX" onClick={onPanelClose}>
          <i className="fa-solid fa-x"></i>
        </Link>
        <div className="userBlogList">{userBlogs}</div>
      </div>
    );
  }

  return <BlogDetails />;
}
