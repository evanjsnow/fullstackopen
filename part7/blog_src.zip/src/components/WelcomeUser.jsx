export default function ({ user, onSignOutButtonClick }) {
  return (
    <p className="welcomeUser">
      Signed in as {user}{" "}
      <button
        className="button buttonSmall signOutButton"
        onClick={onSignOutButtonClick}
      >
        Sign Out
      </button>
    </p>
  );
}
