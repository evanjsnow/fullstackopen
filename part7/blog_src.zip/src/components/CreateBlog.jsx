import { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import FormBlock from "./FormBlock";
import { createBlog } from "../reducers/blogReducer";
import { setGoodNotification } from "../reducers/notificationReducer";

export default function CreateBlog({ user }) {
  const [canSeeButton, setCanSeeButton] = useState(true);
  const [canSeeForm, setCanSeeForm] = useState(false);
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [url, setUrl] = useState("");

  const dispatch = useDispatch();

  function AddBlogButton() {
    return (
      <button
        className="button buttonSmall addBlogButton"
        onClick={handleAddBlogButtonClick}
      >
        <i className="fa-regular fa-circle-plus"></i>&nbsp; Add New Blog
      </button>
    );
  }

  function handleAddBlogButtonClick() {
    setCanSeeButton(false);
    setCanSeeForm(true);
  }

  function handleTitleChange(event) {
    setTitle(event.target.value);
  }

  function handleAuthorChange(event) {
    setAuthor(event.target.value);
  }

  function handleLinkChange(event) {
    setUrl(event.target.value);
  }

  function handleCancelButtonClick(event) {
    event.preventDefault();
    setCanSeeButton(true);
    setCanSeeForm(false);
  }

  const handleCreateBlogSubmit = async (event) => {
    event.preventDefault();
    const title = event.target.title.value;
    const author = event.target.author.value;
    const url = event.target.url.value;

    dispatch(createBlog(title, author, url));
    dispatch(setGoodNotification());

    setTimeout(() => {
      setCanSeeButton(true);
      setCanSeeForm(false);
      setTitle("");
      setAuthor("");
      setUrl("");
    }, 500);
  };

  const addBlogForm = (
    <div className="blogFormContainer">
      <form onSubmit={handleCreateBlogSubmit}>
        <h3>Add a New Blog</h3>
        <div>
          Title:
          <br />
          <input
            type="text"
            className="textFieldClass createBlogField"
            value={title}
            name="title"
            onChange={handleTitleChange}
          />
        </div>
        <div>
          Author:
          <br />
          <input
            type="text"
            className="textFieldClass createBlogField"
            value={author}
            name="author"
            onChange={handleAuthorChange}
          />
        </div>
        <div>
          Link:
          <br />
          <input
            type="text"
            className="textFieldClass createBlogField"
            value={url}
            name="url"
            onChange={handleLinkChange}
          />
        </div>
        <div>
          <button
            className="button cancelButton"
            onClick={handleCancelButtonClick}
          >
            Cancel
          </button>
          <button
            className="button buttonSmall createBlogButton"
            disabled={
              title.length === 0 || author.length === 0 || url.length === 0
            }
            type="submit"
          >
            Create Blog
          </button>
        </div>
      </form>
    </div>
  );

  return (
    <>
      {canSeeButton && <AddBlogButton />}
      {canSeeForm && <FormBlock form={addBlogForm} />}
    </>
  );
}
