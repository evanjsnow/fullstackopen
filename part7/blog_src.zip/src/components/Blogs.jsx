import { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { handleLikeClick, handleDeleteClick } from "../reducers/blogReducer";
import Blog from "./Blog";

const Blogs = ({ user }) => {
  const dispatch = useDispatch();
  const [currentSort, setCurrentSort] = useState("date");
  const [blogsToMap, setBlogsToMap] = useState(null);

  function handleDateSortClick() {
    setCurrentSort("date");
    setBlogsToMap(null);
  }

  function handleLikesSortClick() {
    setCurrentSort("likes");
    setBlogsToMap(likeSortBlogs);
  }

  const dateSort = (
    <>
      <button className="button currentDateSortClass">
        <i className="fa-solid fa-check"></i>&nbsp; Date Created
      </button>
      <button className="button sortLikesClass" onClick={handleLikesSortClick}>
        <i className="fa-regular fa-thumbs-up"></i>&nbsp; Most Likes
      </button>
    </>
  );

  const likesSort = (
    <>
      <button className="button dateSortClass" onClick={handleDateSortClick}>
        <i className="fa-regular fa-calendar"></i>&nbsp; Date Created
      </button>
      <button className="button currentLikesSortClass">
        <i className="fa-solid fa-check"></i>&nbsp; Most Likes
      </button>
    </>
  );

  const sortLinks = (
    <div className="sortBlock">
      Sort By:{"  "}
      {currentSort === "date" && dateSort}
      {currentSort === "likes" && likesSort}
    </div>
  );

  const blogs = useSelector((state) => {
    return state.blogs;
  });

  const likeSortBlogs = [...blogs].sort((a, b) => b.likes - a.likes);

  const blogsList = (!blogsToMap ? blogs : likeSortBlogs).map((blog) => (
    <Blog
      key={blog.id}
      blog={blog}
      onDeleteClick={() => dispatch(handleDeleteClick(blog))}
      onLikeClick={() => dispatch(handleLikeClick(blog))}
    />
  ));

  return (
    <>
      <div className="membersTitle">
        <h1>All Blogs</h1>
      </div>
      {sortLinks}
      <div className="blogListContainer">{blogsList}</div>
    </>
  );
};

export default Blogs;
