export default function FormBlock({ form }) {
  return <div>{form}</div>;
}
