import { useSelector } from "react-redux";

export default function Notification() {
  const message = useSelector((state) => {
    if (state.notification === "HIDE") {
      return null;
    } else if (state.notification === "SHOW_GOOD") {
      return "New blog added";
    } else if (state.notification === "SHOW_LOGIN_GOOD") {
      return "Welcome";
    } else if (state.notification === "SHOW_LOGIN_BAD") {
      return "Invalid credentials";
    }
  });

  const messageClass = useSelector((state) => {
    if (state.notification === "HIDE") {
      return null;
    } else if (state.notification === "SHOW_GOOD") {
      return "bar good";
    } else if (state.notification === "SHOW_LOGIN_GOOD") {
      return "bar good";
    } else if (state.notification === "SHOW_LOGIN_BAD") {
      return "bar bad";
    }
  });

  return <div className={messageClass}>{message}</div>;
}
