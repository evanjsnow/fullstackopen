import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link,
  Navigate,
  useParams,
  useNavigate,
  useMatch,
} from "react-router-dom";

export default function Nav() {
  const navBar = (
    <>
      <div className="nav">
        <Link to="/" className="navLink">
          <i className="fa-duotone fa-blog navIcon"></i>Blog List
        </Link>
        <Link to="/members" className="navLink">
          <i className="fa-duotone fa-users navIcon"></i>Members
        </Link>
      </div>
    </>
  );

  return navBar;
}
