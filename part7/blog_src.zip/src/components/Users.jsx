import { Link } from "react-router-dom";
import { useState } from "react";
import UserBlogs from "./UserBlogs";

export default function Users({ users }) {
  const [blogListClass, setBlogListClass] = useState("hideThing");
  const [targetUser, setTargetUser] = useState("");
  const [userBlogs, setUserBlogs] = useState([]);

  function handleLinkClick(user) {
    setBlogListClass("userBlogListContainer");
    setTargetUser(user);

    if (user.blogs.length === 0) {
      setUserBlogs(`No blogs added by ${user.name}`);
    } else if (user.blogs.length > 0) {
      setUserBlogs(
        user.blogs.map((blog) => <li key={blog.id}>{blog.title}</li>)
      );
    }
  }

  function handlePanelClose() {
    setBlogListClass("hideThing");
    setTargetUser("");
  }

  const userList = users.map((user) => (
    <tr key={user.id}>
      <td>
        <UserBlogs
          blogListClass={blogListClass}
          targetUser={targetUser}
          userBlogs={userBlogs}
          onPanelClose={handlePanelClose}
        />
        <li>
          <Link onClick={() => handleLinkClick(user)}>
            <span className="blogTitle">{user.name}</span>
          </Link>
        </li>
      </td>
      <td width="40px"></td>
      <td align="right">
        <li>
          <span className="blogTitle lighten">{user.blogs.length}</span>
        </li>
      </td>
    </tr>
  ));

  return (
    <>
      <div className="membersTitle">
        <h1>All Blog App Members</h1>
      </div>
      <table className="memberListContainer">
        <tbody>
          <tr>
            <td className="underlineText">
              <br />
              <h2>Member Name</h2>
            </td>
            <td width="40px"></td>
            <td className="underlineText">
              <br />
              <h2>Blogs</h2>
            </td>
          </tr>
          {userList}
        </tbody>
      </table>
    </>
  );
}
