const notificationReducer = (state = "HIDE", action) => {
  switch (action.type) {
    case "SET_NOTIFICATION":
      return action.payload;
    default:
      return state;
  }
};

export const changeNotification = (message, action) => {
  return {
    type: "SET_NOTIFICATION",
    payload: message,
  };
};

export const setGoodNotification = () => {
  return (dispatch) => {
    dispatch(changeNotification("SHOW_GOOD"));

    setTimeout(() => {
      dispatch(changeNotification("HIDE"));
    }, 2000);
  };
};

export const setLoginGoodNotification = () => {
  return (dispatch) => {
    dispatch(changeNotification("SHOW_LOGIN_GOOD"));

    setTimeout(() => {
      dispatch(changeNotification("HIDE"));
    }, 2000);
  };
};

export const hideNotification = () => {
  return (dispatch) => {
    dispatch(changeNotification("HIDE"));
  };
};

export const setLoginBadNotification = () => {
  return (dispatch) => {
    dispatch(changeNotification("SHOW_LOGIN_BAD"));

    setTimeout(() => {
      dispatch(changeNotification("HIDE"));
    }, 2000);
  };
};

export default notificationReducer;
