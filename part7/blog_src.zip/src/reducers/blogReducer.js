import { createSlice } from "@reduxjs/toolkit";
import blogService from "../services/blogs";

const initialState = [];

const blogSlice = createSlice({
  name: "blogs",
  initialState,
  reducers: {
    appendBlog(state, action) {
      state.push(action.payload);
    },
    setBlogs(state, action) {
      return action.payload;
    },
  },
});

export const { appendBlog, setBlogs } = blogSlice.actions;

export const initializeBlogs = () => {
  return async (dispatch) => {
    const blogs = await blogService.getAll();
    dispatch(setBlogs(blogs));
  };
};

export const createBlog = (title, author, url, likes) => {
  return async (dispatch) => {
    const newBlog = await blogService.createNew(title, author, url, likes);
    dispatch(appendBlog(newBlog));
  };
};

export const handleLikeClick = (state) => {
  return async (dispatch) => {
    const blog = state;
    const updatedBlog = { ...blog, likes: blog.likes + 1 };
    const likePlusOne = await blogService.update(state.id, updatedBlog);
    const blogs = await blogService.getAll();
    const updatedBlogs = await blogs.map((blog) =>
      blog.id === state.id ? likePlusOne : blog
    );
    dispatch(setBlogs(updatedBlogs));
  };
};

export const handleDeleteClick = (blog) => {
  const id = blog.id;
  window.confirm("Delete blog?");

  return async (dispatch) => {
    blogService.destroy(id);
    const blogs = await blogService.getAll();
    dispatch(setBlogs(blogs));
  };
};

export default blogSlice.reducer;
